# In this script, I try to define TAD boundaries from normalized Hi-C data. I use the set of merged TADs to find borders 
# and I set the boundaries limits based on changes in interactions.
# This version of the scripts splits the calculation of interactions and the boundaries definition into 2 separate tasks to make it
# less prone to crashes.
# Cyril Matthey-Doret
# 20.10.2016

# edited by Alex
# 07/12/2016
#
# NB: size of (vectorised) TAD interaction matrix is super large (eg 11.7Gb for chr3)
# so ideally the script should be written to process one chromosome at a time! !!!!!!!!!!!!!!!!!!!!!!!!!

############################


# support functions
source( file.path(".","TAD_helper_functions.R"))



# ==============================================================
# Load all data

# global constants # ------------------------------------------
data.folder <- file.path("~", "DATA","TADs")
chromosome.IDs <- paste0("chr",c(1:22, "X"))
filenames <- file.path(data.folder, "norm_hic_data", 
                       paste0(chromosome.IDs,"_5kb_norm.txt.gz"))
names(filenames) <- chromosome.IDs

# tmp restriction for dev # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
filenames <- filenames[3]


# Loading all matrices # --------------------------------------
# matrices are loaded, vectorised, and stored in a list
# can take quite a while!
vec.list <- lapply(filenames, loadTADmatrix) # note: probably not a good idea to vectorise on a desktop: too much I/O for the HDD
names(vec.list) <- names(filenames)


# add some more information to the vec.list lists for further use
sum.na.rm <- function(x, ...) { sum(x, na.rm=TRUE, ...) }
for (i in 1:length(filenames)) { 
  chr.n <- names(filenames)[i]
  vec.list[[chr.n]][["chr"]]                 <- chr.n
  vec.list[[chr.n]][["fn"]]                  <- filenames[i] 
  vec.list[[chr.n]][["diamond_block_size"]]  <- 20         # default for diamond aggregation
  vec.list[[chr.n]][["aggregate_fun"]]       <- sum.na.rm  # default for diamond aggregation
}

rm(filenames)


# check
print(lapply(vec.list, function(l) {c(l$nrow, l$ncol)}))


# load predicted TAD definitions # -------------------------
TAD.df <- read.table(file.path(data.folder, "short_fullover_TAD.bed"))
colnames(TAD.df) <- c("chr","start","end", "TAD_ID")


# check
print(head(TAD.df))




# ==========================================================
# get diamond aggregate interaction scores

# calculate all diamong aggreate scores
# & write to files to avoid issues with crashing
diam.list <- lapply( vec.list, function(l) {
  cat(" === Processing",l$chr,"===", "\n")
  
  cat(" --- Calculating aggregate scores ---", "\n")
  diam <- vec_diam_slide(l, diamond_block_size=l$diamond_block_size, 
                         aggregate_fun=l$aggregate_fun )
  
  cat(" --- Writing file ---", "\n")
  gzfc <- gzfile( file.path(".","DATA",paste0("diam_",l$chr,".tsv.gz")) , "w")
  on.exit( close(gzfc) )
  write.table(diam, file=gzfc,
              sep = "\t",quote=F,row.names = F,col.names = F)
  return(diam)
} ) 


# reload from files if necessary
if (FALSE) {
  diam.list <- lapply( names(vec.list), function(n) {
    cat("Loading diamond aggregate scores for",n,"\n")
    gzfc <- gzfile( file.path(".","DATA",paste0("diam_",vec.list[[n]]$chr,".tsv.gz")) , "r")
    on.exit( if (!is.null(gzfc)) {close(gzfc)} )
    diam <- read.table(file=gzfc,sep = "\t", header = FALSE)
    close(gzfc) ; gzfc <- NULL
    return(diam[,1])
  } )
  names(diam.list) <- names(vec.list)
}


# quick check
lapply(diam.list, length)


# plot
lapply( names(diam.list), function(n) { 
  plot( diam.list[[n]], type="l", ylab="aggregate interaction", col="darkblue", main=n) 
  readline("Press <Enter> to continue...")
} )


# TO IMPROVE: can we just dump the vectorised interaction matrices now??? ????????????????



# ==========================================================
# find boundaries

bound.list <- lapply( names(vec.list), function(chr.n) {
  cat("Finding boundaries for",chr.n,"which has", sum(TAD.df$chr == chr.n),"TADs.","\n")
  find.boundaries( subset(TAD.df, chr == chr.n), diam.list[[chr.n]], do.checks=TRUE )
} )






stop()

# WAS HERE <<<<<<<<<<<<<<<<<<<<<<


# Alternative STEP 1 in case the matrix is too large and needs to be split into overlapping parts:
# NOT TESTED!

D <- 100000; R <- 5000; P <- D/R # The size of the sliding diamond and the resolution will determine how the 2 matrices should overlap.

for(n in c("3")){
  k <- dim(matlist[["3"]][[1]])[1]
  i <- matlist[[n]][[1]][1:(k/2 + P),1:(k/2 + P)]
  diam.i<- vec_diam_slide(i)
  j <- matlist[[n]][[1]][(k/2 - P):k,(k/2 - P):k]
  diam.j<- vec_diam_slide(j)
  diam <- append(diam.i[-((length(diam.i)-(P-1)):length(diam.i))],diam.j[-(1:(P+1))])
  write.table(diam, file=paste0("diam_sums/GM12878/chr",matlist[[n]][[2]]),
              sep = "\t",quote=F,row.names = F,col.names = F)
}
