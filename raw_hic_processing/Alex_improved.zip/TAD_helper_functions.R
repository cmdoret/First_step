#
# helper functions for TAD processing
#


# load TAD # ---------------------------------------------
loadTADmatrix <- function(fn) {
  # TO IMPROVE: could be made much more memory/CPU efficient if:
  #             - only upper triangle or something
  #             - restrict decimals
  #             - already ordered for vectorisation
  stopifnot(require(Matrix))
  cat("Processing",fn,"\n")
  cat("unzipping...")
  tmp <- gzfile(fn,"rt")  # Files are unzipped before being read
  cat("reading...")
  m <- readMM(tmp)
  close(tmp)  # Freeing connection for next matrix
  cat("vectorising...")
  res <- list(  "v"    = as.vector(m), 
                "nrow" = nrow(m), 
                "ncol" = ncol(m) )
  cat("done.\n")
  return(res)
}


# prepare a matrix from vectorised matrix info # ---------
l2matrix <- function(l) {
  # take an element from veclist (ie a list with the vectorised matrix v, nrow and ncol)
  # and make it (greedily) back into a matrix.
  # TO IMPROVE: make sparse? symmetric?
  matrix(l$v, nrow=l$nrow, ncol=l$ncol)
}
# test: l2matrix(veclist[["test"]])


# get vectorised index from (row, column) # ----------------
rc2i <- function(rownum,colnum,nrows){
  # calculate the index of an element in a vector made from a matrix
  # using the row & column numbers for the position in the matrix
  # NB: assumes no upper bounds
  return(((colnum-1)*nrows)+rownum)
}


# get (row, column) from vectorised index # ----------------
i2rc <- function(index, nrows) {
  # calculate the row & column numbers for the position in the matrix 
  # using the index of the element in a vector made from the matrix
  # NB: assumes no upper bounds
  return( c("rownum"=(index %% nrows), "colnum"=(1 + index %/% nrows)) )
}
# test: i2rc(rc2i(3,1,5),5)
# => should return 3 & 1


# get vectorised indices for a sub-square # -----------------
vec_sub_square_indices <- function(
  # info about parent matrix
  nrows, 
  # info about sub square
  sub_top_rownum, sub_left_colnum, 
  sub_nrows, sub_ncols) {
  
  # calculate the vector indices for a sub-square taken from a matrix
  # NB: assumes no upper bounds
  sub_indices <- list()
  for (sub_col in sub_left_colnum:(sub_left_colnum + sub_ncols - 1)) {
    sub_indices[[length(sub_indices) + 1]] <- 
      rc2i(sub_top_rownum, sub_col, nrows):rc2i(
        sub_top_rownum + sub_nrows - 1, sub_col, nrows) 
  }
  return(unlist(sub_indices ))
  
}
# test: vec_sub_square_indices(5, 2, 2, 3, 3)
# => should return 7  8  9 12 13 14 17 18 19


# aggregate values within a sliding diamond # -----------------
vec_diam_slide <- function( l, diamond_block_size=20, aggregate_fun=sum ) {
  # given an element of veclist (ie a list with the vectorised matrix v, nrow & ncol),
  # run a square with its lower left point sliding along (inclusive of) the diagonal of the matrix,
  # aggregating the values found in the square using the provided function,
  # and return these aggregate values.
  
  stopifnot( inherits(l, "list"), all(c("v","nrow","ncol") %in% names(l))  )
  
  rownums <- (diamond_block_size):min( 
    (l$nrow-diamond_block_size + 1),
    (l$ncol-diamond_block_size + 1)
  )
  diam <- rep(NA,l$nrow)
  diam[rownums] <- unlist(lapply( rownums, function(rownum) {
    cat(".") # show a little something of progress
    aggregate_fun(l$v[
      vec_sub_square_indices(l$nrow, rownum - diamond_block_size + 1, rownum, 
                             diamond_block_size, diamond_block_size)  ])
  } )) # note: fast enough so as to not need vectorising
  cat("\n")
  return(diam)
}
# test: tmp <- vec_diam_slide(veclist$test, 3, sum)  ; plot(tmp, type="l") ; l2matrix(veclist[["test"]])
# test: tmp <- vec_diam_slide(veclist$chr3, 20, sum) ; plot(tmp, type="l")


# convert between bin indices and genome positions # -------------
bin_2_pos   <- function(bin, resolution=5000) { 
  # Find the genome position (left bound) from bin number
  return(resolution * (bin - 1)) 
}  

pos_2_bin <- function(pos, resolution=5000) { 
  # Find the bin index (integer) corresponding to given genome position
  return(1 + (pos %/% resolution)) 
}  



# find TAD boundaries # ---------------------------------------------
find.boundaries <- function(chr.TAD.df, chr.diam, threshold.coef=0.1, do.checks=FALSE, resolution=5000){ 
  # this function takes a chromosome-specific TAD dataframe & diamond aggregate scores, 
  # finds boundaries for these TADs, and returns the dataframe with boundary information added.
  # chr.TAD.df:       chromosome-specific data.frame from TAD definition BED file
  # chr.diam:         diamond aggregate score vector for chromosome
  # threshold.coef:   coefficient used for finding TAD boundaries
  
  chr.TAD.df$bad <-
    chr.TAD.df$Rbound.end <- chr.TAD.df$Rbound.start <-
    chr.TAD.df$Lbound.end <- chr.TAD.df$Lbound.start <-  
    chr.TAD.df$maxint <- rep(NA,nrow(chr.TAD.df))
  
  # Find boundaries for each TAD
  # NB: this could be parallelised
  for(i in 1:nrow(chr.TAD.df)){  
    
    # prepare some things
    start.ind <- pos_2_bin(chr.TAD.df$start[i], resolution=resolution)  # transforming TAD start position to row in matrix. Note: TADs are already at 5kb res, so no need to approximate.
    end.ind   <- pos_2_bin(chr.TAD.df$end[i], resolution=resolution)    # Same for end position
    chr.TAD.df[i,"maxint"] <- max(chr.diam[start.ind:end.ind])          # grabbing max interaction value for current TAD
    
    
    # establish left boundary's right end within the TAD:
    # slide rightwards from TAD start until a diam threshold is met
    lr.bin <- start.ind      
    chr.diam.thresh <- (chr.diam[start.ind] + threshold.coef*chr.TAD.df[i,"maxint"])   # (upper) threshold to find boundary end
    while( (lr.bin < end.ind) & (chr.diam[lr.bin] < chr.diam.thresh) ){  
      lr.bin <- (lr.bin + 1)     # End of left boundary -> sliding to the right
    }
    if (lr.bin==end.ind) {
      warning("TAD ",i, " in ", n," had a left boundary that extended all the way to the right of the TAD!")
      chr.TAD.df[i,"bad"] <- TRUE 
    } else { chr.TAD.df[i,"bad"] <- FALSE }
    chr.TAD.df[i,"Lbound.start"] <- bin_2_pos(start.ind, resolution=resolution)         
    chr.TAD.df[i,"Lbound.end"]   <- bin_2_pos(lr.bin,    resolution=resolution)
    
    
    # establish right boundary:
    # slide leftwards from TAD end until a diam threshold is met
    rl.bin <- end.ind                  
    chr.diam.thresh <- (chr.diam[end.ind] + threshold.coef * chr.TAD.df[i,"maxint"])    # (upper) threshold to find boundary end
    while( (rl.bin > start.ind) & (chr.diam[rl.bin] < chr.diam.thresh) ){   
      rl.bin <- (rl.bin - 1)      # Start of right boundary -> sliding to the left
    }
    if (rl.bin==start.ind) {
      warning("TAD ",i, " in ", n," had a right boundary that extended all the way to the left of the TAD!")
      chr.TAD.df[i,"bad"] <- TRUE 
    } # no else: preserve what has already been placed by previous loop
    chr.TAD.df[i,"Rbound.start"] <- bin_2_pos(rl.bin,  resolution=resolution)
    chr.TAD.df[i,"Rbound.end"]   <- bin_2_pos(end.ind, resolution=resolution)
    
  } # next TAD
  
  # my checks
  if (do.checks) {
    chr.TAD.df$TAD.len    <- (chr.TAD.df$end        - chr.TAD.df$start)
    chr.TAD.df$Lbound.len <- (chr.TAD.df$Lbound.end - chr.TAD.df$Lbound.start)
    chr.TAD.df$Rbound.len <- (chr.TAD.df$Rbound.end - chr.TAD.df$Rbound.start)
    
    pairs(chr.TAD.df[,c("TAD.len", "Lbound.len", "Rbound.len")], log="xy",
          col=ifelse(chr.TAD.df$bad,"darkred","darkblue"), lower.panel = NULL,
          upper.panel = function(x,y, ...) { 
            points(x,y, ...) 
            abline(a=0, b=1, col="grey", lty="dashed") } )
    
    readline("Press <Enter> to continue...")
  }
  
  return(chr.TAD.df)
  
}




# EOF